from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('proposal.html',
                           name="Jyoti Jatav",
                           message="क्या तुम मेरी ज़िंदगी का हिस्सा बनोगे, हमेशा के लिए? 💖",
                           profile_img="static/jyoti.jpg")

if __name__ == '__main__':
    app.run(debug=True)